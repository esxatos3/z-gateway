import type { VercelRequest, VercelResponse } from '@vercel/node';

const MAKE = process.env.MAKE_WEBHOOK_URL!;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(200).send('ok');

  const body = req.body || {};
  const msg = body?.message || body?.messages?.[0] || {};
  const chatId: string = body?.chatId || msg?.chatId || msg?.from || msg?.key?.remoteJid || '';

  // 🔹 Se for grupo, ignora
  const isGroup = /@g\.us$/.test(chatId) || body?.isGroup === true || msg?.isGroup === true;
  if (isGroup) return res.status(200).send('ignored (group)');

  // 🔹 Repassa para o Make
  try {
    const r = await fetch(MAKE, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const txt = await r.text();
    return res.status(r.status).send(txt);
  } catch (err: any) {
    return res.status(500).send('error sending to Make: ' + err.message);
  }
}
