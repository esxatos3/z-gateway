import type { VercelRequest, VercelResponse } from '@vercel/node';

const ALLOWED = (process.env.ALLOWED_BUTTON_IDS || '').split(',').map(s=>s.trim());
const MAKE = process.env.MAKE_WEBHOOK_URL!;

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'POST') return res.status(200).send('ok');

  const body = req.body || {};
  const msg = body?.message || body?.messages?.[0] || {};
  const chatId: string = body?.chatId || msg?.chatId || msg?.from || msg?.key?.remoteJid || '';

  // 🔹 filtro grupo x privado
  const isGroup = /@g\.us$/.test(chatId) || body?.isGroup === true || msg?.isGroup === true || msg?.isGroupMsg === true;
  const isPrivate = /@s\.whatsapp\.net$/.test(chatId) || body?.isGroup === false || msg?.isGroup === false;
  if (!isPrivate || isGroup) return res.status(200).send('ignored (group)');

  // 🔹 filtro botões
  const buttonId: string =
    body?.buttonsResponseMessage?.buttonId ||
    msg?.button?.id ||
    msg?.interactive?.button_reply?.id || '';

  const isButton = !!buttonId || body?.type === 'button_response' || msg?.type === 'button' || msg?.type === 'interactive';
  const pass = isButton && ALLOWED.includes(buttonId);

  if (!pass) return res.status(200).send('ignored (not whitelisted button)');

  // 🔹 repassa para o Make
  const r = await fetch(MAKE, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const txt = await r.text();
  return res.status(r.status).send(txt);
}
