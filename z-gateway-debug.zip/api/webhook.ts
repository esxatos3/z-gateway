import type { VercelRequest, VercelResponse } from '@vercel/node';

const MAKE = process.env.MAKE_WEBHOOK_URL!;

function tryParseJSON(raw: string): any {
  try { return JSON.parse(raw); } catch { return null; }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Accept GET (providers sometimes ping)
  if (req.method !== 'POST') {
    console.log('[gateway] non-POST received:', req.method);
    return res.status(200).send('ok');
  }

  // Read raw body for robustness (some providers send text/plain)
  let body: any = req.body;
  if (!body || typeof body === 'string') {
    const raw = typeof req.body === 'string' ? req.body : '';
    body = raw ? tryParseJSON(raw) : {};
  }

  // Fallback: Vercel may not pass raw string; ensure object
  if (!body || typeof body !== 'object') body = {};

  const msg = body?.message || body?.messages?.[0] || {};
  const chatId: string = body?.chatId || msg?.chatId || msg?.from || msg?.key?.remoteJid || '';

  const isGroup =
    /@g\.us$/.test(chatId) ||
    body?.isGroup === true ||
    msg?.isGroup === true ||
    msg?.isGroupMsg === true;

  console.log('[gateway] incoming', {
    method: req.method,
    chatId,
    isGroup,
    hasMessage: !!msg,
    toMake: !!MAKE,
  });

  if (isGroup) {
    console.log('[gateway] ignored: group');
    return res.status(200).send('ignored (group)');
  }

  // Forward to Make
  try {
    const r = await fetch(MAKE, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    const text = await r.text();
    console.log('[gateway] forwarded to Make', { status: r.status, length: text.length });
    return res.status(r.status).send(text || 'ok');
  } catch (err: any) {
    console.error('[gateway] error forwarding to Make', err?.message || err);
    return res.status(500).send('error forwarding to Make');
  }
}
